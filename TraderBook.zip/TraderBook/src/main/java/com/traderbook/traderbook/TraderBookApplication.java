package com.traderbook.traderbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraderBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraderBookApplication.class, args);
	}

}
