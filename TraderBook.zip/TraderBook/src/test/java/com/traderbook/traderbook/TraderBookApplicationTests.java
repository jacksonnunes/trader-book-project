package com.traderbook.traderbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraderBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
